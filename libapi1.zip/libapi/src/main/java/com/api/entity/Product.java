package com.api.entity;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;



@Entity
@Table(name="Products")
public class Product {			
	
	


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "productId")
	private long productId;

	private String productName;

	private String productDesc;



	@ManyToOne(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinColumn(name="pk_attach_id",referencedColumnName ="productId")
	private Attachment attachment;


	public Attachment getAttachment() {
		return attachment;
	}


	public void setAttachment(Attachment attachment) {
		this.attachment = attachment;
	}


	public Product(long productId, String productName, String productDesc) {
		this.productId = productId;
		this.productName = productName;
		this.productDesc = productDesc;
	//	this.productPrice = productPrice;
	}


	public Product() {
	}



	public Product(MultipartFile file) {
		// TODO Auto-generated constructor stub
	}


	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}


	/**
	 * @return the productId
	 */
	public long getProductId() {
		return productId;
	}


	/**
	 * @param productId the productId to set
	 */
	public void setProductId(long productId) {
		this.productId = productId;
	}


	/**
	 * @return the productPrice
	 */
//	public Integer getProductPrice() {
//		return productPrice;
//	}
//
//
//	/**
//	 * @param bs the productPrice to set
//	 */
//	public void setProductPrice(Integer bs) {
//		this.productPrice = bs;
//	}


	public void getAttachment(Attachment att) {
		// TODO Auto-generated method stub

	}


	public void isNotNull() {
		// TODO Auto-generated method stub
		
	}





}
