package com.api.entity;

import java.util.List;

import com.api.entity.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="attachment")
public class Attachment 
{

	@Id
//    @GeneratedValue(generator = "uuid")
//    @GenericGenerator(name = "uuid", strategy = "uuid2") 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "productId")
    private long productId;

    private String fileName;
    private String fileType;
    
    @OneToMany(mappedBy = "attachment",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    private List<Product> product; 
    
	@Lob
    private byte[] data;

    public Attachment(String fileName, String fileType, byte[] data) {
        this.fileName = fileName;
        this.fileType = fileType;
        this.data = data;
    }

 //   private Product product;
  
//    @OneToOne
//    private Product product;
//    
    /**
	 * @return the product
	 */
//	public Product getProduct() {
//		return product;
//	}
//
//	/**
//	 * @param product the product to set
//	 */
//	public void setProduct(Product product) {
//		this.product = product;
//	}

	public Attachment() 
    {
		super();
		
	}

	
	public byte[] getData() {
		return data;
	}


	public void setData(byte[] data) {
		this.data = data;
	}


	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}


	public void getProduct(Product productEntity) {
		// TODO Auto-generated method stub
		
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	

}

