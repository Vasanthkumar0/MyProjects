package com.api.service;



import java.io.IOException;
import java.util.List;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.api.entity.Attachment;
import com.api.entity.Product;
import com.api.helper.Helper;
import com.api.repo.AttachmentRepo;
import com.api.repo.ProductRepo;


@Service
public class ProductService
{
	@Autowired
	private ProductRepo productRepo;

	@Autowired
	private AttachmentRepo attachmentRepo;




	public void save(MultipartFile file) 
	{


		try 
		{
			List<Product> products = Helper.convertExcelToListOfProduct(file.getInputStream());
			
			
			Product productEntity=new Product();
			Attachment attachEntity=new Attachment();

	
			attachEntity.setData(file.getBytes());
			attachEntity.setFileType(file.getContentType());
			attachEntity.setFileName(file.getOriginalFilename());
			
			attachmentRepo.save(attachEntity);
			
			this.productRepo.saveAll(products);
			
//			Product productEntityB=new Product();
//	
//			productEntityA.setAttachment(attachEntity);
//			productEntityB.setAttachment(attachEntity);
//			
//			List<Product> entityAList = productRepo.findAllByattachEntityId(attachEntity.getId());
//
//			List<Product> entityAList = productRepo.findAllByEntityBId(entityB.getId());

		  //attachEntity.getProduct(productEntity);

			//Product saveProduct=productRepo.save(products);

		//	assertThat(saveProduct).isNotNull();
		//	attachmentRepo.save(attachEntity);

		

		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}







	public List<Product> getAllProducts() 
	{
		return this.productRepo.findAll();
	}




	public Attachment saveAttachment(MultipartFile file) throws Exception 
	{

		Attachment attach = new Attachment();
		try
		{
			attach.setData(file.getBytes());
			attach.setFileType(file.getContentType());
			attach.setFileName(file.getOriginalFilename());

			return attachmentRepo.save(attach);

		} 
		catch (Exception e)
		{
			throw new Exception("Could not save File: " + attach);
		}
	}

}



//		boolean saveData=true;
//			try 
//			{
//				if (file != null)
//				{
//					if(saveData)
//					{
//						List<Product> products = Helper.convertExcelToListOfProduct(file.getInputStream());



//						productEntity.getProductId();
//						productEntity.getProductName();
//						productEntity.getProductDesc();
//						productEntity.getProductPrice();
//						
//						productEntity.setProductId(products.size());
//						productEntity.setProductName(products.toString());
//						productEntity.setProductDesc(products.toString());
//						productEntity.setProductPrice(products.hashCode());
//						
//						Product productEntity=new Product();

//						productEntity.setProductId(file.getSize());
//						productEntity.setProductName(file.getContentType());
//						productEntity.setProductDesc(file.getContentType());
//						productEntity.setProductPrice(file.getSize());
//						
//						productRepo.saveAll(productEntity);

//oneToOne



//						    Attachment attach = new Attachment();
//						
//					
//							attach.setData(file.getBytes());
//							attach.setFileType(file.getContentType());
//							attach.setFileName(file.getOriginalFilename());
//							
//							
//							productEntity.setAttachment(attach);
//						    attachmentRepo.save(attach);




//	Attachment attachmentEntity=new Attachment();

//
//						attachmentEntity.setId(products.hashCode());
//						attachmentEntity.setFileName(products.toString());
//						attachmentEntity.setFileType(products.toString());
//						attachmentEntity.setData(products.size());




//						attachmentEntity.setFileName(file.getContentType());
//						attachmentEntity.setFileType(file.getContentType());
//						attachmentEntity.setData(file.getBytes());


//		productEntity.setAttachment(attachmentEntity);
//	productRepo.saveAll(productEntity);
//	   this.productRepo.saveAll(products);
//					}
//				}
//			}
//			catch (IOException e) 
//			{
//				e.printStackTrace();
//			}

//		}














