package com.api.dto;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class ProductDto
{
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private long productId;

	    private String productName;

	    private String productDesc;

	    private long productPrice;

		/**
		 * @return the productId
		 */
		public long getProductId() {
			return productId;
		}

		/**
		 * @param productId the productId to set
		 */
		public void setProductId(long productId) {
			this.productId = productId;
		}

		/**
		 * @return the productName
		 */
		public String getProductName() {
			return productName;
		}

		/**
		 * @param productName the productName to set
		 */
		public void setProductName(String productName) {
			this.productName = productName;
		}

		/**
		 * @return the productDesc
		 */
		public String getProductDesc() {
			return productDesc;
		}

		/**
		 * @param productDesc the productDesc to set
		 */
		public void setProductDesc(String productDesc) {
			this.productDesc = productDesc;
		}

		/**
		 * @return the productPrice
		 */
		public long getProductPrice() {
			return productPrice;
		}

		/**
		 * @param productPrice the productPrice to set
		 */
		public void setProductPrice(long productPrice) {
			this.productPrice = productPrice;
		}
	    
	    
}
