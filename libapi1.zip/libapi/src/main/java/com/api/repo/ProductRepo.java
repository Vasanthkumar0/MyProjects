package com.api.repo;


import com.api.entity.Attachment;
import com.api.entity.Product;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;



public interface ProductRepo extends JpaRepository<Product,Long> 
{
	
//	void save(Attachment attachEntity);

	void save(String products);

//	List<Product> findAllByattachEntityId(long id);

	


	



	
}
